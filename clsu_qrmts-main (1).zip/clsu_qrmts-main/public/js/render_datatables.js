$(document).ready(function () {
    $('#datatable').DataTable();
});
