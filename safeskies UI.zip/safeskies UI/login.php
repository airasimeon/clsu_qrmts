<!DOCTYPE html> 
<html lang="en"> 
<head> 
 <meta name="viewport" content="width=device-width, initial-scale=1.0">  <title>Login System</title> 
 <link rel="stylesheet" href="css/style.css"> 
</head> 
<body>  
    <section class="left-section"> 
        <div id="left-cover" class="cover cover-hide"> 
        <img src="img/sl2.png" alt=""> 
        <h1 style="color:brown;"> Welcome Student Leader!</h1>  <h3 style="color:brown;">Already have an account ?</h3> 
                
        <button type="button" class="switch-btn"  
            onclick="location.reload()">Login</button> 
        </div> 
                <div id="left-form" class="form fade-in-element"> 
                <h1>LOGIN PORTAL</h1> 
                    <form action="login.php" method="post"> 
                    <input type="text" name="user-name" class="input-box"  placeholder="User Name"> 
                    <input type="password" name="user-pass" class="input-box"  placeholder="Password"> 
                    <input type="submit" name="login-btn" class="btn" value="Login">  </form> 
                    </div> 
     </section> 
     <section class="right-section"> 
        <div id="right-cover" class="cover fade-in-element"> 
        <img src="img/logo1.png" alt="">
        <h1 style="color:brown;">Welcome Student Leader !</h1>  <h3 style="color:brown;">Don't have an account ?</h3> 
        <button type="button" class="switch-btn"  
        onclick="switchSignup()">Signup</button> 
        </div> 
        <div id="right-form" class="form form-hide"> 
        <h1>REGISTER PORTAL</h1> 
                    <form action="signup.php" method="post"> 
                    <input type="text" name="user-firstname" class="input-box"  placeholder="firstname"> 
                    <input type="text" name="user-lastname" class="input-box"  placeholder="lastname"> 
                    <input type="text" name="user-name" class="input-box"  placeholder="User Name"> 
                    <input type="email" name="user-email" class="input-box"  placeholder="Email"> 
                    <input type="password" name="user-pass" class="input-box"  placeholder="Password"> 
                    <input type="submit" name="signup-btn" class="btn" value="Signup">  </form> 
                    </div> 
     </section> 
     <script src="js/main.js"></script> 

     
</body> 
</html>
